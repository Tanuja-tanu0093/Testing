const express = require('express');
const path = require('path');
const multer = require('multer');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const validator = require('validator');
const { check, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const app = express();
const PORT = process.env.PORT || 3000;
const http = require('http');
const server = http.createServer(app);
const socketIo = require('socket.io');
const fs = require('fs');
const io = socketIo(server, {
  cors: {
    origin: "http://localhost:3019",
    methods: ["GET", "POST"]
  }
});
// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '..'))); // Serve from parent directory

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/medicareDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    serverSelectionTimeoutMS: 5000
})
.then(() => console.log('Successfully connected to MongoDB'))
.catch(err => {
    console.error('MongoDB connection error:', err);
    process.exit(1);
});
// Configure Multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, 'uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    const filetypes = /jpeg|jpg|png|pdf/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);

    if (extname && mimetype) {
      return cb(null, true);
    } else {
      cb('Error: Only images (JPEG, JPG, PNG) and PDF files are allowed!');
    }
  }
}).single('paymentProof');
// User Schema
const userSchema = new mongoose.Schema({
    firstName: {
        type: String,
        required: [true, 'First name is required'],
        trim: true,
        minlength: [2, 'First name must be at least 2 characters'],
        maxlength: [50, 'First name cannot exceed 50 characters'],
        match: [/^[a-zA-Z]+$/, 'First name can only contain letters']
    },
    lastName: {
        type: String,
        required: [true, 'Last name is required'],
        trim: true,
        minlength: [2, 'Last name must be at least 2 characters'],
        maxlength: [50, 'Last name cannot exceed 50 characters'],
        match: [/^[a-zA-Z]+$/, 'Last name can only contain letters']
    },
    email: {
        type: String,
        required: [true, 'Email is required'],
        unique: true,
        trim: true,
        lowercase: true,
        validate: [validator.isEmail, 'Please provide a valid email']
    },
    password: {
        type: String,
        required: [true, 'Password is required'],
        minlength: [8, 'Password must be at least 8 characters'],
        validate: {
            validator: function(v) {
                return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(v);
            },
            message: 'Password must contain at least one uppercase, one lowercase, one number and one special character'
        },
        select: false
    },
    role: {
        type: String,
        enum: ['patient', 'doctor', 'admin'],
        default: 'patient'
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    lastLogin: Date,
    isActive: {
        type: Boolean,
        default: true
    }
});

// Password Hashing
userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) return next();
    
    try {
        const salt = await bcrypt.genSalt(12);
        this.password = await bcrypt.hash(this.password, salt);
        next();
    } catch (err) {
        console.error('Password hashing error:', err);
        next(new Error('Error processing your password'));
    }
});

const User = mongoose.model('User', userSchema);
// Define Support Request Schema
const supportRequestSchema = new mongoose.Schema({
  requestId: { type: String, default: uuidv4 },
  role: { type: String, required: true },
  name: { type: String },
  email: { type: String },
  phone: { type: String },
  orderId: { type: String },
  adminCode: { type: String },
  issueType: { type: String, required: true },
  priority: { type: String, default: 'medium' },
  description: { type: String, required: true },
  paymentStatus: { type: String, default: 'pending' },
  paymentProof: { type: String },
  status: { type: String, default: 'Open' },
  assignedTo: { type: String },
  resolution: { type: String },
  resolvedAt: { type: Date },
  createdAt: { type: Date, default: Date.now }
});

// Create Model
const SupportRequest = mongoose.model('SupportRequest', supportRequestSchema);

// Signup API
app.post('/api/signup', [
    check('firstName').trim().isLength({ min: 2 }).withMessage('First name must be at least 2 characters'),
    check('lastName').trim().isLength({ min: 2 }).withMessage('Last name must be at least 2 characters'),
    check('email').isEmail().withMessage('Please provide a valid email').normalizeEmail(),
    check('password').isStrongPassword({
        minLength: 8,
        minLowercase: 1,
        minUppercase: 1,
        minNumbers: 1,
        minSymbols: 1
    }).withMessage('Password must be at least 8 characters with at least one uppercase, one lowercase, one number and one special character')
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ 
            status: 'fail', 
            errors: errors.array().map(err => err.msg) 
        });
    }

    try {
        const { firstName, lastName, email, password } = req.body;

        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ 
                status: 'fail', 
                error: 'Email already exists' 
            });
        }

        const newUser = await User.create({ 
            firstName, 
            lastName, 
            email, 
            password 
        });

        newUser.password = undefined;

        res.status(201).json({
            status: 'success',
            message: 'User created successfully',
            data: { user: newUser }
        });
    } catch (error) {
        console.error('Signup error:', error);

        if (error.code === 11000) {
            return res.status(400).json({ 
                status: 'fail', 
                error: 'Email already exists' 
            });
        }

        if (error.name === 'ValidationError') {
            const messages = Object.values(error.errors).map(err => err.message);
            return res.status(400).json({ 
                status: 'fail', 
                error: messages.join('. ') 
            });
        }

        res.status(500).json({ 
            status: 'error', 
            error: 'Internal server error' 
        });
    }
});

// Serve HTML files
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/home.html'));
});
app.get('/signup', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/signup.html'));
});
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/dashboard.html'));
});

app.get('/home', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/home.html'));
});
app.get('/products', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/cart.html'));
});
app.get('/contact', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/support.html'));
});
app.get('/about.html', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/about.html'));
});
app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/dashboard_old.html'));
});
app.get('/cart', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/cart.html'));
});
 
// Handle form submission
app.post('/submit-request', (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ success: false, message: err });
    }

    try {
      const { role, customerName, customerEmail, customerPhone, orderId, adminCode, 
              issueType, priority, description, paymentStatus } = req.body;

      const newRequest = new SupportRequest({
        role,
        name: customerName || null,
        email: customerEmail || null,
        phone: customerPhone || null,
        orderId: orderId || null,
        adminCode: adminCode || null,
        issueType,
        priority: priority || 'medium',
        description,
        paymentStatus: paymentStatus || 'pending',
        paymentProof: req.file ? `/uploads/${req.file.filename}` : null
      });

      await newRequest.save();

      // Emit new query event to all connected clients
      io.emit('newQueryNotification', newRequest);

      res.json({
        success: true,
        message: 'Request submitted successfully! Our team will contact you soon.',
        request: newRequest
      });
    } catch (error) {
      console.error('Error saving request:', error);
      res.status(500).json({ success: false, message: 'Error submitting request' });
    }
  });
});

// Get all support requests (for admin view)
app.get('/api/requests', async (req, res) => {
  try {
    const requests = await SupportRequest.find().sort({ createdAt: -1 });
    res.json(requests);
  } catch (error) {
    console.error('Error fetching requests:', error);
    res.status(500).json({ error: 'Error fetching requests' });
  }
});

// Get single request by ID
app.get('/api/requests/:id', async (req, res) => {
  try {
    const request = await SupportRequest.findOne({ requestId: req.params.id });
    if (!request) {
      return res.status(404).json({ error: 'Request not found' });
    }
    res.json(request);
  } catch (error) {
    console.error('Error fetching request:', error);
    res.status(500).json({ error: 'Error fetching request' });
  }
});

// Update request status
app.put('/api/requests/:id', async (req, res) => {
  try {
    const { status, resolution, priority, assignedTo } = req.body;
    const request = await SupportRequest.findOneAndUpdate(
      { requestId: req.params.id },
      { 
        status,
        resolution,
        priority,
        assignedTo,
        resolvedAt: status === 'Resolved' ? new Date() : null
      },
      { new: true }
    );
    
    if (!request) {
      return res.status(404).json({ error: 'Request not found' });
    }
    
    // Emit update event
    io.emit('queryUpdate', request);
    
    res.json(request);
  } catch (error) {
    console.error('Error updating request:', error);
    res.status(500).json({ error: 'Error updating request' });
  }
});

// Delete request
app.delete('/api/requests/:id', async (req, res) => {
  try {
    const request = await SupportRequest.findOneAndDelete({ requestId: req.params.id });
    if (!request) {
      return res.status(404).json({ error: 'Request not found' });
    }
    
    // Emit delete event
    io.emit('queryDeleted', req.params.id);
    
    res.json({ success: true, message: 'Request deleted successfully' });
  } catch (error) {
    console.error('Error deleting request:', error);
    res.status(500).json({ error: 'Error deleting request' });
  }
});

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

//image load tobe cleanup
app.get('/painrelief.webp', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/painrelief.webp'));
});
app.get('/image1.jpeg', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/image1.jpeg'));
});
app.get('/image2', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/image2.jpeg'));
});
app.get('/image3', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/image3.jpeg'));
});
app.get('/cough%20syrup.jpg', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/cough syrup.jpg'));
});
app.get('/sleep%20aid.webp', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/sleep aid.webp'));
});
app.get('/multivitamin%20complex.webp', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/multivitamin complex.webp'));
});
app.get('/Antibiotics.jpg', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/Antibiotics.jpg'));
});
app.get('/allergy%20relief.jpg', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/allergy relief.jpg'));
});
app.get('/digestive.webp', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/digestive.webp'));
});
app.get('/vitamin-d3.webp', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/vitamin-d3.webp'));
});
app.get('/paracetamol.jpg', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/paracetamol.jpg'));
});
app.get('/ibuprofen.jpg', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/ibuprofen.jpg'));
});
app.get('/omeprazole%20magnesium.jpg', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/omeprazole magnesium.jpg'));
});
app.get('/omeprazole%20magnesium.jpg', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/omeprazole magnesium.jpg'));
});
app.get('/omeprazole.webp', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/omeprazole.webp'));
});
app.get('cetrizine.jpeg', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/cetrizine.jpeg'));
});
app.get('atorvastatin.webp', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/atorvastatin.webp'));
});
app.get('support.jpeg', (req, res) => {
    res.sendFile(path.join(__dirname, '../Medical_Management_System.html/support.jpeg'));
});


// Error Handling
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ 
        status: 'error', 
        error: 'Internal server error',
        message: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
});


// Start Server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});