    const firebaseConfig = {
        apiKey: "AIzaSyCvEypU2xfKWHxeI4NXxj0M8F7OtPL-gXU",
        authDomain: "supportpage-23dce.firebaseapp.com",
        databaseURL: "https://supportpage-23dce-default-rtdb.firebaseio.com",
        projectId: "supportpage-23dce",
        storageBucket: "supportpage-23dce.firebasestorage.app",
        messagingSenderId: "65265859693",
        appId: "1:65265859693:web:fa7fdb50beff58d57c1364"
      };
      firebase.initializeApp(firebaseConfig);
    var supportpageDB=  firebase.database().ref('supportpage');
    document.getElementById('supportFormSection').addEventListener('submit',supportform);
    function supportpage(e){
        e.preventDefault();
    var name=getElementVal('name');
    var emailid=getElementVal('emailid');
    var msgContent=getElementVal("messageContent");
    // console.log(name,emailid,msgContent);

    saveMessages(name,emailid,msgContent);
    }
    const saveMessages=(name,emailid,msgContent)=>{
        var newContactForm=contactFormDB.push();
        newContactForm.set({
            name:name,
            emailid:emailid,
            msgContent:msgContent,
        })
    }
const getElementVal=(id)=>{
    return document.getElementById(id).ariaValueMax;

};
