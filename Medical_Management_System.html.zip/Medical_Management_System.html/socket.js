const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const bodyParser = require('body-parser');
const multer = require('multer');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');

const port = 3019;
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Middleware
app.use(cors());
app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// MongoDB Connection
mongoose.connect('mongodb://127.0.0.1:27017/support_center', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('MongoDB connection successful');
});

// Define Support Request Schema
const supportRequestSchema = new mongoose.Schema({
  requestId: { type: String, default: uuidv4 },
  role: { type: String, required: true },
  name: { type: String },
  email: { type: String },
  phone: { type: String },
  orderId: { type: String },
  description: { type: String, required: true },
  status: { type: String, default: 'Open' },
  priority: { type: String, default: 'medium' },
  assignedTo: { type: String },
  resolution: { type: String },
  resolutionForm: { type: String },
  resolvedBy: { type: String },
  resolvedAt: { type: Date },
  createdAt: { type: Date, default: Date.now }
});

// Create Model
const SupportRequest = mongoose.model('SupportRequest', supportRequestSchema);

// Configure Multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, 'uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    const filetypes = /jpeg|jpg|png|pdf/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);

    if (extname && mimetype) {
      return cb(null, true);
    } else {
      cb('Error: Only images (JPEG, JPG, PNG) and PDF files are allowed!');
    }
  }
}).single('paymentProof');

// Socket.io connection
io.on('connection', (socket) => {
  console.log('New client connected');
  
  socket.on('disconnect', () => {
    console.log('Client disconnected');
  });
  
  // Handle agent login
  socket.on('agentLogin', (agentData) => {
    console.log(`Agent logged in: ${agentData.name}`);
    socket.join('agents');
    io.to('agents').emit('agentStatus', { 
      agentId: agentData.id, 
      status: 'online', 
      name: agentData.name 
    });
  });
  
  // Handle agent logout
  socket.on('agentLogout', (agentData) => {
    console.log(`Agent logged out: ${agentData.name}`);
    socket.leave('agents');
    io.to('agents').emit('agentStatus', { 
      agentId: agentData.id, 
      status: 'offline', 
      name: agentData.name 
    });
  });
});

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'support.html'));
});

// Handle form submission
app.post('/submit-request', (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ success: false, message: err });
    }

    try {
      const { role, name, email, phone, orderId, description } = req.body;

      const newRequest = new SupportRequest({
        role,
        name,
        email,
        phone,
        orderId,
        description
      });

      await newRequest.save();

      // Emit new query event to all connected dashboard clients
      io.emit('newQuery', {
        id: newRequest.requestId,
        customer: name,
        contact: `${email} | ${phone}`,
        title: `Support Request #${newRequest.requestId}`,
        description: description,
        date: newRequest.createdAt.toISOString().replace('T', ' ').substring(0, 16),
        status: 'pending',
        priority: 'medium',
        assignedTo: null
      });

      res.json({
        success: true,
        message: 'Request submitted successfully!',
        request: newRequest
      });
    } catch (error) {
      console.error('Error saving request:', error);
      res.status(500).json({ success: false, message: 'Error submitting request' });
    }
  });
});

// Get all support requests
app.get('/api/requests', async (req, res) => {
  try {
    const requests = await SupportRequest.find().sort({ createdAt: -1 });
    res.json(requests);
  } catch (error) {
    console.error('Error fetching requests:', error);
    res.status(500).json({ error: 'Error fetching requests' });
  }
});

// Get requests for dashboard
app.get('/api/dashboard/requests', async (req, res) => {
  try {
    const requests = await SupportRequest.find().sort({ createdAt: -1 });
    const formattedRequests = requests.map(request => ({
      id: request.requestId,
      customer: request.name,
      contact: `${request.email} | ${request.phone}`,
      title: `Support Request #${request.requestId}`,
      description: request.description,
      date: request.createdAt.toISOString().replace('T', ' ').substring(0, 16),
      status: request.status === 'Open' ? 'pending' : 'resolved',
      priority: request.priority || 'medium',
      assignedTo: request.assignedTo || null
    }));
    res.json(formattedRequests);
  } catch (error) {
    console.error('Error fetching requests:', error);
    res.status(500).json({ error: 'Error fetching requests' });
  }
});

// Update request
app.put('/api/requests/:id', async (req, res) => {
  try {
    const updates = req.body;
    const request = await SupportRequest.findOneAndUpdate(
      { requestId: req.params.id },
      updates,
      { new: true }
    );
    
    if (!request) {
      return res.status(404).json({ error: 'Request not found' });
    }
    
    // Emit update event to dashboard
    io.emit('queryUpdate', {
      id: request.requestId,
      status: request.status === 'Open' ? 'pending' : 'resolved',
      priority: request.priority,
      assignedTo: request.assignedTo,
      resolution: request.resolution
    });
    
    res.json(request);
  } catch (error) {
    console.error('Error updating request:', error);
    res.status(500).json({ error: 'Error updating request' });
  }
});

// Start server
server.listen(port, () => {
  console.log('Server started on port', port);
});