// Scroll to Products Section
function scrollToProducts() {
    document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
}

// Go Back to Previous Page
function goBack() {
    window.history.back();
}

// Add Arrow Key Navigation
document.addEventListener('keydown', function(event) {
    if (event.key === 'ArrowLeft') {
        goBack();
    }
    if (event.key === 'ArrowRight') {
        scrollToProducts();
    }
});
