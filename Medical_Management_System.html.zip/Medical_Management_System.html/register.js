<script type="module">
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-analytics.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyDhA0LXenBdYEEdp5fFfRueawjIoVKMmCc",
    authDomain: "signupemployee.firebaseapp.com",
    projectId: "signupemployee",
    storageBucket: "signupemployee.firebasestorage.app",
    messagingSenderId: "665399656816",
    appId: "1:665399656816:web:cd39af655b0a5492e68fb5",
    measurementId: "G-BYGH0SMRKL"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
</script>